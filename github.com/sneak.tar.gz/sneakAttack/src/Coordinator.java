import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Coordinator {

    private boolean isVillainAssigned;
    private List<Player> alivePlayers = new ArrayList<>();
    private boolean isVillainSuspected;
    private boolean isHealerAssigned;
    private boolean isSherlockAssigned;

    public static void main(String... args) {
        int numberOfPlayers = 6;
        Coordinator coordinator = new Coordinator();

        while (numberOfPlayers > 0) {
            Player player = new Player(coordinator.assignRole(), "P" + numberOfPlayers);
            coordinator.alivePlayers.add(player);
            numberOfPlayers -= 1;
        }

        coordinator.startGame();
        System.out.println(coordinator.alivePlayers.toString());
    }

    private void startGame() {
        System.out.println(alivePlayers.toString());
        while (!isGameOver()) {
            reset();
            System.out.println("Round begins");
            playRound();
            System.out.println("Remaining Players:" + alivePlayers);
        }
    }

    private void reset() {
        alivePlayers.forEach(player -> {
            player.suspectedBy.clear();
            player.status = Status.Alive;
        });
    }

    private boolean isGameOver() {
        if (isVillainSuspected) {
            System.out.println("Villain is suspected. Innocents win");
            return true;
        }
        if (alivePlayers.size() == 2) {
            System.out.println("Only one innocent left. Villain wins");
            return true;
        }
        return false;
    }

    private void playRound() {
        for (Player player : alivePlayers) {
            List<Player> otherPlayers = new ArrayList<>(alivePlayers);
            player.role.action(player, otherPlayers);
        }

        for (Player player : alivePlayers) {
            System.out.println(player.name + " is suspected By:" + player.suspectedBy);
        }

        Player playerToKill = null;
        List<Player> mostSuspectedPlayers = new ArrayList<>();
        int maxSuspectedCount = 0;
        for (Player player : alivePlayers) {
            if (player.status == Status.Dead) {
                playerToKill = player;
            }

            maxSuspectedCount = populateMaxSuspected(mostSuspectedPlayers, maxSuspectedCount, player);
            if (player.status == Status.Healed)
                System.out.println("Healed Player:" + player.name);
        }

        if (playerToKill == null) {
            System.out.println("Killed Player is healed");
            isVillainSuspected = false;
        } else {
            System.out.println("Killed Player:" + playerToKill.name);
            alivePlayers.remove(playerToKill);
        }

        System.out.println("Most Suspected Player:" + mostSuspectedPlayers.toString());

        mostSuspectedPlayers.removeIf(player -> player.status == Status.Healed);
        alivePlayers.removeAll(mostSuspectedPlayers);
    }

    private int populateMaxSuspected(List<Player> mostSuspectedPlayers, int maxSuspectedCount, Player player) {
        if (player.suspectedBy.size() > maxSuspectedCount) {
            mostSuspectedPlayers.clear();
            isVillainSuspected = false;
            mostSuspectedPlayers.add(player);
            if (player.role instanceof Villain && player.status != Status.Healed) {
                this.isVillainSuspected = true;
            }
            maxSuspectedCount = player.suspectedBy.size();
        } else if (player.suspectedBy.size() == maxSuspectedCount) {
            mostSuspectedPlayers.add(player);
            if (player.role instanceof Villain && player.status != Status.Healed) {
                this.isVillainSuspected = true;
            }
        }
        return maxSuspectedCount;
    }

    private Role assignRole() {
        List<Class<? extends Role>> assignableRoles = new ArrayList<>();
        assignableRoles.add(Villain.class);
        assignableRoles.add(Healer.class);
        assignableRoles.add(Innocent.class);
        assignableRoles.add(Sherlock.class);

        if (this.isVillainAssigned) {
            assignableRoles.remove(Villain.class);
        }
        if (this.isHealerAssigned) {
            assignableRoles.remove(Healer.class);
        }
        if (this.isSherlockAssigned){
            assignableRoles.remove(Sherlock.class);
        }

        int pick = new Random().nextInt(assignableRoles.size());
        Class<? extends Role> assigned = assignableRoles.get(pick);

        switch (assigned.getSimpleName()) {
            case "Villain":
                this.isVillainAssigned = true;
                return new Villain();
            case "Healer":
                this.isHealerAssigned = true;
                return new Healer();
            case "Sherlock":
                this.isSherlockAssigned = true;
                return new Sherlock();
            case "Innocent":
                return new Innocent();
        }

        return null;
    }
}

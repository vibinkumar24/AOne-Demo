import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Innocent implements Role {

    @Override
    public void action(Player innocentPlayer, List<Player> otherPlayers) {
        suspectPlayer(innocentPlayer, otherPlayers);
    }

    void suspectPlayer(Player innocentPlayer, List<Player> otherPlayers) {
        Player suspectedPlayer = null;
        boolean suspectedPlayerFound = false;
        while (!suspectedPlayerFound) {
            Scanner in = new Scanner(System.in);
            System.out.println("I am " + innocentPlayer.name + " I suspect:");
            String playerToSuspect = in.nextLine();

            Optional<Player> playerToSuspectOptional = otherPlayers.stream()
                    .filter(potentialPlayer -> potentialPlayer.name.equals(playerToSuspect))
                    .findFirst();

            if (!playerToSuspectOptional.isPresent()) {
                System.out.println("Such a player does not exist. Enter valid player name");
                continue;
            }

            suspectedPlayer = playerToSuspectOptional.get();
            if (suspectedPlayer.name.equals(innocentPlayer.name)) {
                System.out.println("Player cannot suspect himself. Enter another innocent player's name:\n");
                suspectedPlayer = null;
                continue;
            }
            suspectedPlayerFound = true;
        }
        suspectedPlayer.suspectedBy.add(innocentPlayer);
    }

    @Override
    public String toString() {
        return "Innocent";
    }
}

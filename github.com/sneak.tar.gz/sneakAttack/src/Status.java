public enum Status {
    Alive,
    Dead,
    Checked, Healed
}

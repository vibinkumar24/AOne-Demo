import java.util.List;

public interface Role {
    void action(Player player, List<Player> players);

}

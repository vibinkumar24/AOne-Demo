import java.util.ArrayList;
import java.util.List;

public class Player {
    String name;
    Role role;
    Status status = Status.Alive;
    List<Player> suspectedBy = new ArrayList<>();

    Player(Role role, String name) {
        this.role = role;
        this.name = name;
    }

    @Override
    public String toString() {
        return name + ":" + role;
    }
}

import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Healer extends Innocent implements Role {

    @Override
    public void action(Player healer, List<Player> otherPlayers) {
        healPlayer(healer, otherPlayers);
        suspectPlayer(healer, otherPlayers);
    }

    private void healPlayer(Player healer, List<Player> otherPlayers) {
        Player healedplayer = null;
        boolean playerToHealFound = false;

        while (!playerToHealFound) {
            Scanner in = new Scanner(System.in);
            System.out.println("I am " + healer.name + " I heal:");
            String playerToHeal = in.nextLine();

            Optional<Player> playerToHealOptional = otherPlayers.stream()
                    .filter(potentialPlayer -> potentialPlayer.name.equals(playerToHeal))
                    .findFirst();

            if (!playerToHealOptional.isPresent()) {
                System.out.println("Such a player does not exist. Enter valid player name");
                continue;
            }

            healedplayer = playerToHealOptional.get();
            playerToHealFound = true;
        }
        healedplayer.status = Status.Healed;
    }

    @Override
    public String toString() {
        return "Healer";
    }
}

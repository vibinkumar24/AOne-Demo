import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Sherlock extends Innocent implements Role {

    @Override
    public void action(Player sherlock, List<Player> otherPlayers) {
        checkPlayer(sherlock, otherPlayers);
        suspectPlayer(sherlock, otherPlayers);
    }

    private void checkPlayer(Player sherlock, List<Player> otherPlayers) {
        Player checkedPlayer = null;
        boolean playerToCheckFound = false;

        while (!playerToCheckFound) {
            Scanner in = new Scanner(System.in);
            System.out.println("I am " + sherlock.name + " I check:");
            String playerToCheck = in.nextLine();

            Optional<Player> playerToCheckOptional = otherPlayers.stream()
                    .filter(potentialPlayer -> potentialPlayer.name.equals(playerToCheck))
                    .findFirst();

            if (!playerToCheckOptional.isPresent()) {
                System.out.println("Such a player does not exist. Enter valid player name");
                continue;
            }

            checkedPlayer = playerToCheckOptional.get();
            if (checkedPlayer.name.equals(sherlock.name)) {
                System.out.println("Player cannot check himself. Enter another player's name:\n");
                checkedPlayer = null;
                continue;
            }

            checkedPlayer = playerToCheckOptional.get();
            playerToCheckFound = true;
        }

        if(checkedPlayer.role instanceof Villain) {
            System.out.println("Checked player is Villain");
        }
    }

    @Override
    public String toString() {
        return "Sherlock";
    }
}

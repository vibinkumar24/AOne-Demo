import java.util.List;
import java.util.Optional;
import java.util.Scanner;

public class Villain implements Role {

    @Override
    public void action(Player killer, List<Player> otherPlayers) {
        Player killedPlayer = null;
        boolean playerToKillFound = false;

        while (!playerToKillFound) {
            Scanner in = new Scanner(System.in);
            System.out.println("I am " + killer.name + " I will kill:");
            String playerToKill = in.nextLine();

            Optional<Player> playerToKillOptional = otherPlayers.stream()
                    .filter(potentialPlayer -> potentialPlayer.name.equals(playerToKill))
                    .findFirst();

            if (!playerToKillOptional.isPresent()) {
                System.out.println("Such a player does not exist. Enter valid player name:\n");
                continue;
            }

            killedPlayer = playerToKillOptional.get();
            if (killedPlayer.name.equals(killer.name)) {
                System.out.println("Villain cannot kill himself. Enter an innocent player's name:\n");
                killedPlayer = null;
                continue;
            }
            playerToKillFound = true;
        }
        if (killedPlayer.status != Status.Healed) {
            killedPlayer.status = Status.Dead;
        }

    }

    @Override
    public String toString() {
        return "Villain";
    }
}
